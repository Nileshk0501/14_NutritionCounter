export { Property13Bars } from "./Property13Bars";
