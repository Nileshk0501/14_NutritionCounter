export { Frame39 } from "./Frame39";
