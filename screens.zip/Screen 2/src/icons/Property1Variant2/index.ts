export { Property1Variant2 } from "./Property1Variant2";
