export { Property13Bars1 } from "./Property13Bars1";
