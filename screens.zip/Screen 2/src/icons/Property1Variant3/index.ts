export { Property1Variant3 } from "./Property1Variant3";
