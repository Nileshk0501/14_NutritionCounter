export { BatteryDark1 } from "./BatteryDark1";
