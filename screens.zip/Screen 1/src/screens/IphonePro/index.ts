export { IphonePro } from "./IphonePro";
