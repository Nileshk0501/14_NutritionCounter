export { Notch2 } from "./Notch2";
