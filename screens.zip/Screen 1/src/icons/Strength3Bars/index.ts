export { Strength3Bars } from "./Strength3Bars";
