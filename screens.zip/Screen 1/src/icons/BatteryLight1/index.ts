export { BatteryLight1 } from "./BatteryLight1";
